const MENU_ROOT = "subra-cache-root";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_ROOT,
    title: "Subra Cache",
    contexts: ["page"]
  });

  chrome.contextMenus.create({
    id: "clear-localization",
    parentId: MENU_ROOT,
    title: "Clear Localization Cache",
    contexts: ["page"]
  });

  chrome.contextMenus.create({
    id: "clear-database",
    parentId: MENU_ROOT,
    title: "Clear Database Cache",
    contexts: ["page"]
  });

  chrome.contextMenus.create({
    id: "clear-all",
    parentId: MENU_ROOT,
    title: "Clear All Cache",
    contexts: ["page"]
  });
});

async function clearCache(type, tabId) {
  if (!tabId) return;

  const tabs = await chrome.tabs.query({active: true, currentWindow: true});
  const tab = tabs.find(t => t.id === tabId) || tabs[0];

  if (!tab || !tab.url) return;

  try {
    const url = new URL("/hap4e/bg/admin/clear_cache", tab.url);

    if (type !== "all") {
      url.searchParams.set("type", type);
    }

    const response = await fetch(url.href, {
      method: "GET",
      credentials: "include",
      cache: "no-store",
      redirect: "follow"
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: "Subra Cache",
      message:
        type === "4" ? "Localization cache cleared." :
        type === "1" ? "Database cache cleared." :
        "All cache cleared."
    });
  } catch (error) {
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: "Subra Cache",
      message: `Cache clearing failed: ${error.message}`
    });
  }
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "clear-localization") clearCache("4", tab.id);
  if (info.menuItemId === "clear-database") clearCache("1", tab.id);
  if (info.menuItemId === "clear-all") clearCache("all", tab.id);
});

chrome.commands.onCommand.addListener(async command => {
  const tabs = await chrome.tabs.query({active: true, currentWindow: true});
  const tab = tabs[0];
  if (!tab) return;

  if (command === "clear-localization") clearCache("4", tab.id);
  if (command === "clear-database") clearCache("1", tab.id);
  if (command === "clear-all") clearCache("all", tab.id);
});
