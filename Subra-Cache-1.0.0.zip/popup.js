const buttons = document.querySelectorAll(".action");
const siteEl = document.getElementById("site");
const statusDot = document.getElementById("statusDot");
const result = document.getElementById("result");
const resultIcon = document.getElementById("resultIcon");
const resultTitle = document.getElementById("resultTitle");
const resultMessage = document.getElementById("resultMessage");

let currentUrl = null;

function showResult(success, title, message) {
  result.classList.remove("hidden", "error");
  if (!success) result.classList.add("error");
  resultIcon.textContent = success ? "✓" : "!";
  resultTitle.textContent = title;
  resultMessage.textContent = message || "";
}

function getEndpoint(type) {
  const url = new URL("/hap4e/bg/admin/clear_cache", currentUrl.origin);
  if (type !== "all") {
    url.searchParams.set("type", type);
  }
  return url.href;
}

async function clearCache(type) {
  if (!currentUrl) {
    showResult(false, "Unavailable", "The current tab is not supported.");
    return;
  }

  if (type === "all") {
    const confirmed = confirm(
      "Clear ALL cache?\n\nThis will clear all application caches."
    );
    if (!confirmed) return;
  }

  buttons.forEach(button => button.disabled = true);
  result.classList.add("hidden");

  try {
    const response = await fetch(getEndpoint(type), {
      method: "GET",
      credentials: "include",
      cache: "no-store",
      redirect: "follow"
    });

    const text = await response.text();

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    let message = "Cache cleared successfully.";

    try {
      const data = JSON.parse(text);
      if (data.message) message = data.message;
      else if (data.success === false) throw new Error(data.message || "The server rejected the request.");
    } catch (e) {
      if (e.message && e.message !== "Unexpected token '<', \"<html>\" is not valid JSON") {
        if (e.message.startsWith("The server rejected")) throw e;
      }
    }

    const title =
      type === "4" ? "Localization cache cleared" :
      type === "1" ? "Database cache cleared" :
      "All cache cleared";

    showResult(true, title, message);
  } catch (error) {
    showResult(false, "Cache clearing failed", error.message || "Unknown error.");
  } finally {
    buttons.forEach(button => button.disabled = false);
  }
}

async function init() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs[0];

  if (!tab || !tab.url) {
    siteEl.textContent = "No active page";
    statusDot.classList.add("offline");
    return;
  }

  try {
    currentUrl = new URL(tab.url);

    const supported =
      currentUrl.protocol === "https:" &&
      (currentUrl.hostname === "subra.bg" || currentUrl.hostname.endsWith(".subra.bg"));

    if (!supported) {
      siteEl.textContent = currentUrl.hostname;
      statusDot.classList.add("offline");
      buttons.forEach(button => button.disabled = true);
      showResult(false, "Unsupported site", "Open the Subra admin panel first.");
      return;
    }

    siteEl.textContent = currentUrl.hostname;
    statusDot.classList.add("online");
  } catch {
    siteEl.textContent = "Invalid URL";
    statusDot.classList.add("offline");
    buttons.forEach(button => button.disabled = true);
  }
}

buttons.forEach(button => {
  button.addEventListener("click", () => clearCache(button.dataset.type));
});

init();
